
//	import java.sql.Connection;
//	import java.sql.DriverManager;
//	import java.sql.ResultSet;
//	import java.sql.SQLException;
//	import java.sql.Statement;
//
//	public class readExcel {
//	  public static Connection getConnection() throws Exception {
//	    String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
//	    String url = "jdbc:odbc:excelDB";
//	    String username = "username";
//	    String password = "pass";
//	    Class.forName(driver);
//	    return DriverManager.getConnection(url, username, password);
//	  }
//
//	  public static void main(String args[]) {
//	    Connection conn = null;
//	    Statement stmt = null;
//	    ResultSet rs = null;
//	    try {
//	      conn = getConnection();
//	      stmt = conn.createStatement();
//	      String excelQuery = "select * from [Sheet1$]";
//	      rs = stmt.executeQuery(excelQuery);
//
//	      while (rs.next()) {
//	        System.out.println(rs.getString("Groupon") + " " + rs.getString("Car") + " "
//	            + rs.getString("LastName"));
//	      }
//	    } catch (Exception e) {
//	      System.err.println(e.getMessage());
//	    } finally {
//	      try {
//	        rs.close();
//	        stmt.close();
//	        conn.close();
//
//	      } catch (SQLException e) {
//	        e.printStackTrace();
//	      }
//	    }
//	  }
//	}


	import java.io.FileInputStream;
	import java.io.IOException;

	import org.apache.poi.hssf.usermodel.HSSFCell;
	import org.apache.poi.hssf.usermodel.HSSFRow;
	import org.apache.poi.hssf.usermodel.HSSFSheet;
	import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
	public class readExcel{

	    private static HSSFWorkbook xlWBook;
	    private static HSSFSheet xlSheet;
	    private static HSSFRow xlRow;
	    private static HSSFCell xlCell;
	    private static String filePath = "D:\\Eclipse\\Java\\Coupon_Managment_system\\src\\";
	    private static String fileName = "coupon.xls";

	    public static void main(String[] args) throws InterruptedException {

	        try {

	            FileInputStream xlFile = new FileInputStream(filePath + fileName);

	            // Access the required test data sheet

	            xlWBook = new HSSFWorkbook(xlFile);

	            // Assuming your data is in Sheet1- if not use your own sheet name
	            xlSheet = xlWBook.getSheet("Data");

	            // gives row count in sheet
	            int noOfRows = xlSheet.getPhysicalNumberOfRows();

	            // gives column count in sheet
	            xlRow = xlSheet.getRow(0);
	            int noOfColumns = xlRow.getLastCellNum();

	            // excelData - 2 dimm array - stores all the excel data -Sheet1 only
	            String[][] excelData = new String[noOfRows][noOfColumns];

	            // r - row c- column
	            for (int r = 0; r < noOfRows; r++) {
	                for (int c = 0; c < noOfColumns; c++) {
	                    xlRow = xlSheet.getRow(r);
	                    xlCell = xlRow.getCell(c);

	                    // Here we have complete excel data in an array -excelData-

//	                    excelData[r][c] = xlCell.getStringCellValue();
	                    switch (c) {
	    	            case 0:
	                        //aBook.setCouponprovider(nextCell.getStringCellValue());
	                        Couponprovider = excelData[r][c];
	                        System.out.println(Couponprovider);
	                        break;
	                    case 1:
	                        //aBook.setName_of_product(nextCell.getStringCellValue());
	                        Name_of_product = excelData[r][c];
	                        System.out.println(Name_of_product);
	                        break;
	                    case 2:
	                        //aBook.setPrice((float) nextCell.getNumericCellValue());
	                        price = excelData[r][c];
	                        System.out.println(price);
	                        break;
	                    case 5:
	                        //aBook.setStatus_of_Coupon(nextCell.getStringCellValue());
	                        Status_of_Coupon = excelData[r][c]; 
	                        System.out.println(Status_of_Coupon);                
	                        break;
	                    case 4:
	                        //aBook.setDiscount_rate((float) nextCell.getNumericCellValue());
	                        discount_rate = excelData[r][c];
	                        System.out.println(discount_rate);
	                        break;
	                    case 3:
	                        //aBook.setExpiration_period((float) nextCell.getNumericCellValue());
	                        expiration_period = excelData[r][c];
	                        System.out.println(expiration_period);
	                        break;
	                    case 7:
	                        //aBook.setCoupon_ID((float) nextCell.getNumericCellValue());
	                        Coupon_ID = excelData[r][c];
	                        System.out.println(Coupon_ID);
	                        break;
	    	               
	    	            }
	                    
	                   // excelData[r][c] = xlCell.getStringCellValue();

//	                     System.out.println("row: " + r + " column: " + c);
//	                     System.out.println(excelData[r][c]);	
	                }
	            }

	            // creating an array to store isExected column
	            String[][] isExecuted = new String[noOfRows][1];

	            for (int row = 1; row < noOfRows; row++) {
	                // here column is always only one
	                // so c=0

	                // extracting a isExecuted column - and considering it as last
	                // column in sheet
	                // in your case it is not then - count the column position : use
	                // position-1
	                // ex: if column position is 7 then use 6 as below
	                // isExecuted[row][0]= excelData[row][6];

	                isExecuted[row][0] = excelData[row][noOfColumns - 1];

	                if (isExecuted[row][0].equalsIgnoreCase("yes")) {

	                    // accessing complete row -which isExecuted=Yes

	                    // *********IMPORTANT*****
	                    for (int col = 0; col < noOfColumns; col++) {
	                        // prints all the rows where isExecuted column has Yes
	                        System.out.println(excelData[row][col]);
	                    }
	                }

	                // System.out.println(isExecuted[row][0]);

	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	    }
	}
	



