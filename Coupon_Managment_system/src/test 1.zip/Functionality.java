
public interface Functionality {
	
	

}
